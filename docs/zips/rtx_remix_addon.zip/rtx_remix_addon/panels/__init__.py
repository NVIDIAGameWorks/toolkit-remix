import bpy

from .viewport_panel import REMIX_PT_ViewportPanel

def register():
    bpy.utils.register_class(REMIX_PT_ViewportPanel)

def unregister():
    bpy.utils.unregister_class(REMIX_PT_ViewportPanel)
    
if __name__ == "__main__":
    register()
    