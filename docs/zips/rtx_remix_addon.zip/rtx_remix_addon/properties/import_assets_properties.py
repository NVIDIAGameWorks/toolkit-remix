import bpy

class REMIX_PG_ImportAssetsProperties(bpy.types.PropertyGroup):
    assets_scale: bpy.props.FloatProperty(
        name="Assets Scale",
        description="Scale factor for imported assets",
        default=1.0,
        min=0.0001,
        max=10000.0
    )
    
    create_collection: bpy.props.BoolProperty(
        name="Create Collection",
        description="Create a new collection for imported assets",
        default=True
    )